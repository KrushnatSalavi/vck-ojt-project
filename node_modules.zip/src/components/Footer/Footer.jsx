import './Footer.css'

const Footer = () =>{
return(
  <div id='footer'>
    <p id="footer-text">© 2025 Vivekanand College. All rights reserved.</p>
  </div>
);

}

export default Footer;
